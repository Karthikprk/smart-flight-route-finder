import java.util.*;

class FlightRouteFinder {

	// Class to represent a flight with destination and time
	static class Flight {
		String destination;
		int time;

		public Flight(String destination, int time) {
			this.destination = destination;
			this.time = time;
		}
	}

	// Function to find the shortest flight path
	public static void findShortestRoute(Map<String, List<Flight>> graph, String start, String destination) {
		if (!graph.containsKey(start) || !graph.containsKey(destination)) {
			System.out.println("Start or destination city not found in the graph.");
			return;
		}

		// Priority queue to select the city with the minimum travel time
		PriorityQueue<Map.Entry<String, Integer>> pq = new PriorityQueue<>(Comparator.comparingInt(Map.Entry::getValue));
		Map<String, Integer> timeToCity = new HashMap<>();
		Map<String, String> previousCity = new HashMap<>();

		// Initialize all cities with infinite time, except for the start city
		for (String city : graph.keySet()) {
			timeToCity.put(city, Integer.MAX_VALUE);
		}
		timeToCity.put(start, 0);

		// Add start city to the priority queue
		pq.offer(new AbstractMap.SimpleEntry<>(start, 0));

		while (!pq.isEmpty()) {
			Map.Entry<String, Integer> current = pq.poll();
			String currentCity = current.getKey();
			int currentTime = current.getValue();

			// If we reached the destination city, stop the search
			if (currentCity.equals(destination)) {
				break;
			}

			// Explore all neighbors (flights)
			if (graph.containsKey(currentCity)) {
				for (Flight flight : graph.get(currentCity)) {
					int newTime = currentTime + flight.time;
					if (newTime < timeToCity.get(flight.destination)) {
						timeToCity.put(flight.destination, newTime);
						previousCity.put(flight.destination, currentCity);
						pq.offer(new AbstractMap.SimpleEntry<>(flight.destination, newTime));
					}
				}
			}
		}

		// Check if the destination city is reachable
		if (timeToCity.get(destination) == Integer.MAX_VALUE) {
			System.out.println("Destination city is not reachable from the start city.");
		} else {
			// Print the shortest route and total time
			printRoute(previousCity, start, destination);
			System.out.println("Total time: " + timeToCity.get(destination) + " minutes");
		}
	}

	// Function to print the path from start to destination using the previous city map
	private static void printRoute(Map<String, String> previousCity, String start, String destination) {
		Stack<String> route = new Stack<>();
		String current = destination;
		while (current != null) {
			route.push(current);
			current = previousCity.get(current);
		}
		System.out.print("Shortest route: ");
		while (!route.isEmpty()) {
			System.out.print(route.pop());
			if (!route.isEmpty()) {
				System.out.print(" -> ");
			}
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// Create the graph representing cities and flight routes
		Map<String, List<Flight>> graph = new HashMap<>();

		// Updated graph with clear flight routes
		graph.put("New York", Arrays.asList(new Flight("Paris", 5), new Flight("London", 8)));
		graph.put("Paris", Arrays.asList(new Flight("London", 3), new Flight("Dublin", 7)));
		graph.put("London", Arrays.asList(new Flight("Paris", 3), new Flight("New York", 8)));
		graph.put("Dublin", Arrays.asList(new Flight("Paris", 7)));
		graph.put("France", Arrays.asList(new Flight("London", 10), new Flight("New York", 20)));

		// Get user input for start and destination cities
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the start city: ");
		String startCity = scanner.nextLine();
		System.out.print("Enter the destination city: ");
		String destinationCity = scanner.nextLine();

		// Find the shortest route using Dijkstra's algorithm
		findShortestRoute(graph, startCity, destinationCity);

		scanner.close();
	}
}
